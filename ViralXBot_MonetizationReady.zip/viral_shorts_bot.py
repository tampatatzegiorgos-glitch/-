import time, random, os, re
# DUDE ViralXBot - Monetization-Optimized Version
print('[DUDE] ViralXBot 24/7 is running with monetization strategy...')

UPLOAD_TIMES = [11, 15, 19]  # Upload slots

COMMENTS = [
    "🔥 Who else thinks this is insane?!",
    "💯 This goes HARD!",
    "😂 Can’t stop watching this!",
    "👇 Drop your thoughts below 👇"
]

def wait_for_next_slot():
    while True:
        hour = int(time.strftime("%H"))
        if hour in UPLOAD_TIMES:
            print(f"[DUDE] Upload window opened at {hour}:00")
            break
        time.sleep(600)  # wait 10 min

def trending_yt():
    # Placeholder: would fetch trending YT clips
    return [("https://yt.fake/video1", "Cristiano Ronaldo insane skills"),
            ("https://yt.fake/video2", "Elon Musk podcast moment")]

def trending_tt():
    # Placeholder: would fetch trending TikToks
    return [("https://tt.fake/video3", "Wild viral clip"), 
            ("https://tt.fake/video4", "Funny moment caught live")]

def generate_viral_title(title):
    words = re.findall(r"\w+", title)
    hooks = ["Insane", "Unbelievable", "Exposed", "The Truth", "Crazy", "🔥 Must Watch 🔥"]
    main = random.choice(words).capitalize()
    viral_title = f"{main} {random.choice(hooks)}! {title[:40]}"
    hashtags = ["#" + w.lower() for w in words[:3]] + ["#viral","#shorts","#trending"]
    return viral_title, hashtags

def dl_vid(url, name):
    print(f"[DUDE] Downloading: {url}")
    return name + ".mp4"

def rm_wm(file):
    print(f"[DUDE] Removing watermark: {file}")
    return file

def edit_vid(file, title):
    print(f"[DUDE] Editing video: {file} with title {title}")
    return file.replace(".mp4", "_edit.mp4")

def upload(file, title, tags):
    print(f"[DUDE] Uploading {file} with title '{title}' and tags {tags}")
    return "video123"

def post_comment(video_id, text):
    print(f"[DUDE] Comment posted on {video_id}: {text}")

def log_performance(video_id, title):
    with open("video_log.txt","a") as f:
        f.write(f"{time.time()} | {video_id} | {title}\n")

# ---- Main 24/7 Loop ----
while True:
    wait_for_next_slot()
    videos = trending_yt() + trending_tt()
    selected = random.sample(videos, 3)  # Upload 3 per slot
    for u, title in selected:
        try:
            name = ''.join(x for x in title[:15] if x.isalnum() or x in '_-')
            viral_title, hashtags = generate_viral_title(title)
            edited = edit_vid(rm_wm(dl_vid(u, name)), title)
            vid = upload(edited, viral_title, hashtags)
            post_comment(vid, random.choice(COMMENTS))
            log_performance(vid, viral_title)
        except Exception as e:
            print(f"[DUDE] Error: {e}")
            continue
