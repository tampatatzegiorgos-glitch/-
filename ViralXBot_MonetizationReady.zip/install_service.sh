#!/bin/bash
nohup python3 viral_shorts_bot.py &